package grails.plugin.asyncmail

import org.codehaus.groovy.grails.commons.GrailsApplication
import org.springframework.validation.ObjectError

class AsynchronousMailService {
    boolean transactional = true;
    AsynchronousMailMessageBuilderFactory asynchronousMailMessageBuilderFactory;
    GrailsApplication grailsApplication;

    /**
     * Create synchronous message and save it to DB.
     *
     * If configuration flag asynchronous.mail.send.immediately is true (default)
     * then this method start send job after create message
     */
    def sendAsynchronousMail(Closure callable) {
        def messageBuilder = asynchronousMailMessageBuilderFactory.createBuilder();
        callable.delegate = messageBuilder;
        callable.resolveStrategy = Closure.DELEGATE_FIRST
        callable.call()

        // Mail message
        AsynchronousMailMessage message = messageBuilder.message;

        // Get immediately behavior configuration
        boolean immediately;
        if (messageBuilder.immediatelySetted) {
            immediately = messageBuilder.immediately;
        } else {
            immediately = grailsApplication.config.asynchronous.mail.send.immediately
        }
        immediately = immediately && message.beginDate.time <= System.currentTimeMillis();

        // Save message to DB
        if (!message.save(flush: immediately)) {
            StringBuilder errorMessage = new StringBuilder();
            message.errors?.allErrors?.each {ObjectError error ->
                errorMessage.append(error.getDefaultMessage());
            }
            throw new Exception(errorMessage.toString());
        }

        // Start job immediately
        if (immediately) {
            log.trace("Start send job immediately.");
            sendImmediately();
        }

        // Return message object 
        return message;
    }

    /**
     * Start send job immediately. If you send more than one message in one method,
     * you can disable asynchronous.mail.send.immediately flag (default true) and use this method
     * after then create all messages.
     *
     * <code>asynchronousMailService.sendAsynchronousMail{...}<br/>
     * asynchronousMailService.sendAsynchronousMail{...}<br/>
     * asynchronousMailService.sendAsynchronousMail{...}<br/>
     * asynchronousMailService.sendImmediately()</code>
     */
    def sendImmediately() {
        AsynchronousMailJob.triggerNow(
                ['messagesAtOnce': grailsApplication.config.asynchronous.mail.messages.at.once]
        );
    }
}
